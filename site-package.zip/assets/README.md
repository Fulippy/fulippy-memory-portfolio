# 素材替换入口

- `dreamcore-pink-cottage.png`：首页梦核草地；房屋热点在 `src/data/hotspots.ts` 中对齐。
- `dreamcore-copier-room-16x9.png`：第二场景；复印机热点同样在 `src/data/hotspots.ts` 中管理。
- `极乐.jpg`：XP 桌面壁纸。
- `关于我.ico`、`作品集精选.ico`、`能做到的事.ico`、`联系我.ico`、`退出.ico`：桌面应用图标。
- `profile/zhang-lifu.webp`：个人资料照片。
- `projects/`：六个项目各自的网页展示图。

场景图建议保持 16:9、至少 1600 × 900。替换场景构图后，请同步调整热点的百分比坐标。
